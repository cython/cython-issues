import cProfile
import cython_test
import numpy as np

from test_cython import cython_test as cython_test_package
import cython_test

np.random.seed(3428790)
arr = np.random.rand(1e6)

code_double_nopack = """
for i in range(100):
    cython_test.get_array_number(arr)
"""
code_double_pack = """
for i in range(100):
    cython_test_package.get_array_number(arr)
"""
cProfile.runctx(code_double_nopack, globals(), locals(), sort="cumulative")
cProfile.runctx(code_double_pack, globals(), locals(), sort="cumulative")

code_fused_nopack = """
for i in range(100):
    cython_test.get_array_fused_number(arr)
"""
code_fused_pack = """
for i in range(100):
    cython_test_package.get_array_fused_number(arr)
"""
cProfile.runctx(code_fused_nopack, globals(), locals(), sort="cumulative")
cProfile.runctx(code_fused_pack, globals(), locals(), sort="cumulative")
