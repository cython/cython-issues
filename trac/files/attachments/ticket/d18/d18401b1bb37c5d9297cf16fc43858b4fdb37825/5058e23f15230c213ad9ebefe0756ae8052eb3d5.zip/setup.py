from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
from Cython.Distutils import build_ext


ext_module_flow = Extension(
    "cython_test",
    ["cython_test.pyx"],
    language="c++",
    include_dirs=['.'],
)


setup(
    ext_modules=cythonize([ext_module_flow], annotate=True),
    cmdclass={'build_ext': build_ext},
)
