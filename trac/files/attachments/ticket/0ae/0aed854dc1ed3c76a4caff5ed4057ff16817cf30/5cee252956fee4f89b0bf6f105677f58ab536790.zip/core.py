# encoding: utf-8
# cython: profile=False
# cython: language_level=3
import cython

@cython.cclass
class BaseClass(object):
	attr = cython.declare(unicode)
	def __cinit__(self):
		self.attr = "something"
	def __init__(self):
		if not cython.compiled:
			self.__cinit__()

@cython.cclass
class Subclass(BaseClass):
	pass
