import core
import core_nocython

print(core_nocython.Subclass().attr)
print(core.Subclass().attr)
