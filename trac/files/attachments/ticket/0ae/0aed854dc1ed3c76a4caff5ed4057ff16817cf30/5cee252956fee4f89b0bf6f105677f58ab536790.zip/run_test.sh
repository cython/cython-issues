python setup.py build_ext --inplace
python test_core.py
rm *.so *.pyc *.c
rm -rf build
