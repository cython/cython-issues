# python setup.py build_ext --inplace

from distutils.core import setup
from distutils.extension import Extension
from Cython.Distutils import build_ext

name = "cythonside2"

setup(
    cmdclass = {'build_ext': build_ext},
    ext_modules = [
        Extension(name, 
                  sources=[name+".pyx",
                           "cside.cpp",
                       ],
                  language="c++",                   # remove this if C and not C++

             )
        ]
)           