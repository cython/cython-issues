
template<typename A, typename B> void fun(A *arg1, B *arg2);





