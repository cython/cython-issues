#include <stdio.h>

#include "cside.hpp"


template<typename A, typename B> void fun(A *arg1, B *arg2) {
  printf("In fun\n");
}

template void fun(int *arg1, int *arg2);

